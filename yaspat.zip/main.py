import sys

from PyQt5 import uic
from PyQt5.QtCore import QTime
from PyQt5.QtWidgets import QMainWindow, QApplication


class MyWidget(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('untitled.ui', self)
        self.pushButton.clicked.connect(self.run)

    def run(self):
        time = self.timeEdit.time().toString()
        data = self.calendarWidget.selectedDate().toPyDate()
        text = self.lineEdit.text() if str(self.lineEdit.text()) else ""
        self.listWidget.addItem(f'{data} {time} - {text}')
        time = QTime()
        time.setHMS(0, 0, 0)
        self.timeEdit.setTime(time)




if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyWidget()
    ex.show()
    sys.exit(app.exec_())
